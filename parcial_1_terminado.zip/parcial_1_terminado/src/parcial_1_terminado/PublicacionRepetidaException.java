
package parcial_1_terminado;

public class PublicacionRepetidaException extends Exception {
    public PublicacionRepetidaException(String mensaje) {
        super(mensaje);
    }
}