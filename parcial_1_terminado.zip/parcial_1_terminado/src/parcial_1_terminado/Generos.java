    

package parcial_1_terminado;

public enum Generos {
    FICCION,
   NO_FICCION, 
   CIENCIA,
   HISTORIA
    
}
