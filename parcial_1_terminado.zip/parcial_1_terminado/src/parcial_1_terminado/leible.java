
package parcial_1_terminado;

public interface  leible {

    public void leer();
}
