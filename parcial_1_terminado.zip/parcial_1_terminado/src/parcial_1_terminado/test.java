import java.util.Scanner;

public class test {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;

        while (opcion != 3) {  // Cambio el 5 por 3 ya que ahora hay 3 opciones
            // Mostrar menú
            System.out.println("Menu:");
            System.out.println("1. Mostrar todas las publicaciones");
            System.out.println("2. Ingresar nuevo animal");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer del scanner

            switch (opcion) {
                case 1:
                    // Mostrar todas las publicaciones (aquí podrías mostrar los animales)
                    System.out.println("\nMostrando todos los animales:");
                    // Aquí deberías imprimir la lista de animales, por ejemplo:
                    // zoologico.mostrarAnimales();
                    break;

                case 2:
                    // Ingresar un nuevo animal
                    System.out.println("\nIngresando un nuevo animal:");

                    // Solicitar tipo de animal
                    System.out.println("¿Qué tipo de animal quieres ingresar?");
                    System.out.println("1. Ave");
                    System.out.println("2. Mamífero");
                    System.out.println("3. Reptil");
                    int tipoAnimal = scanner.nextInt();
                    scanner.nextLine();  // Limpiar el buffer

                    // Solicitar detalles del animal
                    System.out.print("Nombre del animal: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Edad del animal: ");
                    int edad = scanner.nextInt();
                    scanner.nextLine();  // Limpiar el buffer

                    switch (tipoAnimal) {
                        case 1:  // Ave
                            System.out.print("Embergadura del ala: ");
                            double embergaduraAla = scanner.nextDouble();
                            scanner.nextLine();  // Limpiar el buffer
                            // Crear un objeto de tipo Ave
                            Animal Ave = new Aves(embergaduraAla, nombre, edad);
                            // Aquí deberías agregar el animal a la colección del zoológico
                            // zoologico.agregarAnimal(ave);
                            break;

                        case 2:  // Mamífero
                            System.out.print("Peso: ");
                            double peso = scanner.nextDouble();
                            scanner.nextLine();  // Limpiar el buffer
                            System.out.println("Tipo de dieta (1: Herbívoro, 2: Carnívoro):");
                            int tipoDieta = scanner.nextInt();
                            TipoDeDieta dieta = (tipoDieta == 1) ? TipoDeDieta.HERBIVORO : TipoDeDieta.CARNIVORO;
                            // Crear un objeto de tipo Mamífero
                            Animal mamifero = new Mamiferos(peso, dieta, nombre, edad);
                            // Aquí deberías agregar el animal a la colección del zoológico
                            // zoologico.agregarAnimal(mamifero);
                            break;

                        case 3:  // Reptil
                            System.out.print("Tipo de escama: ");
                            String tipoEscama = scanner.nextLine();
                            System.out.print("Regulación de temperatura (Ectotérmico/Endotérmico): ");
                            String regTemperatura = scanner.nextLine();
                            // Crear un objeto de tipo Reptil
                            Animal reptil = new Reptiles(nombre, edad, tipoEscama, regTemperatura);
                            // Aquí deberías agregar el animal a la colección del zoológico
                            // zoologico.agregarAnimal(reptil);
                            break;

                        default:
                            System.out.println("Opción no válida para el tipo de animal.");
                            break;
                    }
                    break;

                case 3:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }

        scanner.close();
    }
}
