
package recuperatorio.primer.parcial;

public class Crucero extends Nave {
    private int cantidadPasajeros;

    public Crucero(int cantidadPasajeros, String nombre, int capacidadPasajeros, int añoLanzamiento) {
        super(nombre, capacidadPasajeros, añoLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String toString() {
        return "Crucero{"+"su nombre es " + nombre  +
                " tiene la cantidadPasajeros"
                + cantidadPasajeros
                +
                "el año de salida fue en " + 
                añoLanzamiento +
                "su capacidad es "+
                capacidadPasajeros +
                + '}';
    }
    
    

}