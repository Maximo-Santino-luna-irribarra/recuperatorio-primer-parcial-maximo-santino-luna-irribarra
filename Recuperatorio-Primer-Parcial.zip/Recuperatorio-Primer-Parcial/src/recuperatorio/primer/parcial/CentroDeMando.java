package recuperatorio.primer.parcial;
import java.util.List;
import java.util.ArrayList;

public class CentroDeMando {
    private List<Nave> naves; // Cambiado a List para mayor flexibilidad

    public CentroDeMando() {
        this.naves = new ArrayList<>(); // Se inicializa como ArrayList por defecto
    }
    public void agregaNave(Nave nave) throws  PesoCargueroException,NaveDuplicadaException {
        if (naves.contains(nave)) {
            throw new NaveDuplicadaException("La nave ya esta registrada: " + nave.getNombre());
        }
        naves.add(nave);
    }
    public void mostrarNaves(){
    for (Nave nave : naves){
            System.out.println(nave.toString());
        }
    }
    public void Explorar(){
        for (Nave nave : naves){
            if (nave instanceof explora){
                ((explora) nave).explora();
            }
        }
    }
    
}
