
package recuperatorio.primer.parcial;


public enum TipoDeMision {
    CARTOGRAFIA, 
    INVESTIGACION, 
    CONTACTO;
    
}
