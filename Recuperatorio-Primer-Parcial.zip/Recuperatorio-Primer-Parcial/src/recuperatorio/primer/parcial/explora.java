
package recuperatorio.primer.parcial;


public interface explora {
    public void explora();
    
}
