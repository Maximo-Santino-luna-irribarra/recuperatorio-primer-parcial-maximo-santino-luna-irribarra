/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatorio.primer.parcial;

import java.util.Objects;


public abstract  class Nave {
    protected String nombre;
    protected int capacidadPasajeros;
    protected int añoLanzamiento;

    public Nave(String nombre, int capacidadPasajeros, int añoLanzamiento) {
        this.nombre = nombre;
        this.capacidadPasajeros = capacidadPasajeros;
        this.añoLanzamiento = añoLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidadPasajeros() {
        return capacidadPasajeros;
    }

    public int getAñoLanzamiento() {
        return añoLanzamiento;
    }

 @Override
    public int hashCode() {
        return Objects.hash(nombre, capacidadPasajeros, añoLanzamiento);
    }

 @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Nave nave = (Nave) obj;
        return capacidadPasajeros == nave.capacidadPasajeros &&
                añoLanzamiento == nave.añoLanzamiento &&
                Objects.equals(nombre, nave.nombre);
    }

    
}
