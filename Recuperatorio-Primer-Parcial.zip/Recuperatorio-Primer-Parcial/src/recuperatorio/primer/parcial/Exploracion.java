
package recuperatorio.primer.parcial;

class Exploracion extends Nave implements explora{
    private TipoDeMision mision;

    public Exploracion(TipoDeMision mision, String nombre, int capacidadPasajeros, int añoLanzamiento) {
        super(nombre, capacidadPasajeros, añoLanzamiento);
        this.mision = mision;
    }

   

    @Override
    public void explora() {
        System.out.println("se esta explorando en la nave de exploracion " + nombre);
    }

    @Override
    public String toString() {
        return "Exploracion{" + "esta nave de exploracion se llama " + nombre + "y su mision es "
                + mision +
                "el año de salida fue en " + 
                añoLanzamiento +
                "su capacidad es "+
                capacidadPasajeros +
                + '}';
    }
    
 

    
}
