
package recuperatorio.primer.parcial;
import java.util.Scanner;

public class test {

    public static void main(String[] args) throws PesoCargueroException  {
        Scanner scanner = new Scanner(System.in);
        CentroDeMando centroDeMando = new CentroDeMando();
        int opcion = 0;
      
        // Crear varias naves con diferentes tipos
        Carguero cargueroGalactica = new Carguero(300, "Galactica", 100, 2024);
        Carguero carguero1 = new Carguero(400, "Galactica", 100, 2024);  // Nave duplicada por nombre
        Exploracion naveExplora = new Exploracion(TipoDeMision.CARTOGRAFIA,"Explorador", 2, 2784);
        Crucero crucero = new Crucero(500, "Las Bahams", 200, 2700);
        Carguero carguero2 = new Carguero(400, "Astronómico", 150, 1900);
        Carguero cargueroInvalid2 = new Carguero(600, "Carga extrema", 100, 2024); // Invalid
        // Agregar las naves al centro de mando
        try {
            centroDeMando.agregaNave(cargueroInvalid2);
            centroDeMando.agregaNave(cargueroGalactica);
            centroDeMando.agregaNave(naveExplora);
            centroDeMando.agregaNave(crucero);
            centroDeMando.agregaNave(carguero2);
            System.out.println("Naves agregadas exitosamente.");
            // Intentar agregar una nave duplicada
            centroDeMando.agregaNave(carguero1);  // Aquí debería lanzarse la excepción
        } catch (NaveDuplicadaException e) {
            System.out.println(e.getMessage());  // Debería capturar el error si se intenta agregar un duplicado
       // } catch (PesoCargueroException e) { NO llege
         //   System.out.println("Error al crear el carguero: " + e.getMessage());

        // Menú para interactuar con el programa
        while (opcion != 3) {
            System.out.println("Menú:");
            System.out.println("1 Mostrar todas las naves");
            System.out.println("2 Leer publicaciones legibles");
            System.out.println("3 Salir");
            System.out.print("Seleccione una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer del scanner

            switch (opcion) { 
                case 1:
                    // Mostrar todas las naves
                    System.out.println("\nMostrando todas las naves:");
                    centroDeMando.mostrarNaves();  // Este método debe estar implementado en CentroDeMando
                    break;
                
                case 2:
                    // Iniciar exploración de naves
                    System.out.println("\nLeyendo publicaciones legibles (exploración de naves):");
                    centroDeMando.Explorar();// Se cambia de "Explorar" a "iniciarExploracion"
                    break;
                
                case 3:
                    System.out.println("Saliendo...");
                    break;
                
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }

        scanner.close();
        }
    

    }}