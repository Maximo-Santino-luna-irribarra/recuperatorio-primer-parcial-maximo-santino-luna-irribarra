/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatorio.primer.parcial;

/**
 *
 * @author lunam
 */
class Carguero extends  Nave implements explora{
    private int capacidadCarga;
    private static  int PESO_MINIMO = 100;  
    private static  int PESO_MAXIMO = 500;

    public Carguero(int capacidadCarga, String nombre, int capacidadPasajeros, int añoLanzamiento) throws PesoCargueroException {
        super(nombre, capacidadPasajeros, añoLanzamiento);
       // if (capacidadCarga < PESO_MINIMO || capacidadCarga > PESO_MAXIMO) {
         //   throw new PesoCargueroException("El peso de la carga debe estar entre 100 y 500 toneladas. El peso actual es: " + capacidadCarga);
        //}
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void explora() {
        System.out.println(" el carguero " + nombre +" esta explorando ");
    }

    @Override
    public String toString() {
        return "Carguero{" +"el crucero se llama"+ 
                nombre + "este cargero tiene la  capacida de carga de " + 
                capacidadCarga + "el año de salida fue en " + 
                añoLanzamiento +
                "su capacidad es "+
                capacidadPasajeros +
                '}';
    }
    
    
    
    
}
